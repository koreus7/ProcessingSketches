Purchase a commercial license here: http://www.fontmonger.com

Font usage: Personal use only, no commercial use allowed
Distributed by: Font Monger

This font may not be used without permission. 
Without Font Premission:
You may not edit this font
You may not rename this font
You may not repackage, distribute, or sale this font
You may not use this font in multimeda, tv, applications, video games, or film.


For a commercial use license visit:
http://www.fontmonger.com

